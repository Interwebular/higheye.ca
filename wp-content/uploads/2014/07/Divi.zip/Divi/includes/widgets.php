<?php
get_template_part( 'includes/widgets/widget-about' );
get_template_part( 'includes/widgets/widget-adsense' );
get_template_part( 'includes/widgets/widget-ads' );